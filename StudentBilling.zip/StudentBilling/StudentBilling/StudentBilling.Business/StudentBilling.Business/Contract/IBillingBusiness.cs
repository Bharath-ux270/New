﻿using StudentBilling.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Business.Contract
{
    public interface IBillingBusiness
    {
        public Task<List<BillingInfo>> GetStudentBillById(int Id);
        public Task<List<PaymentHistory>> GetPayments();
        public Task<List<PaymentHistory>> GetPaymentHistory(int Id);
        Task<PaymentHistory> AddPayment(PaymentHistory entity);
        Task<PaymentHistory> UpdatePayment(PaymentHistory entity);
        Task<bool> DeletePayment(int id);
        Task<bool> paymentexist(int id);

    }
}
