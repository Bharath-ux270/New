﻿using StudentBilling.Business.Contract;
using DM = StudentBilling.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DC = StudentBilling.Data.Models;
using AutoMapper;
using StudentBilling.Repository.Contract;
using Microsoft.EntityFrameworkCore;

namespace StudentBilling.Business.Implementation
{
    public  class BillingBusiness : IBillingBusiness
    {
        private readonly IMapper mapper;
        private IBillingRepository billingRepository;
        public BillingBusiness(IMapper mapper, IBillingRepository billingRepository) 
        {
            this.mapper = mapper;
            this.billingRepository = billingRepository;
        }

        public Task<List<DM.BillingInfo>> GetStudentBillById(int StudentId)
        {
            try
            {
                List<DC.BillingInfo> result = this.billingRepository.GetStudentBillById(StudentId);
                List<DM.BillingInfo> dbresult = mapper.Map<List<DM.BillingInfo>>(result);

                return Task.FromResult(dbresult);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Task<List<DM.PaymentHistory>> GetPayments()
        {
            try
            {
                List<DC.PaymentHistory> result = this.billingRepository.GetPayments();
                List<DM.PaymentHistory> dbresult = mapper.Map<List<DM.PaymentHistory>>(result);

                return Task.FromResult(dbresult);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public Task<List<DM.PaymentHistory>> GetPaymentHistory(int StudentId)
        {
            try
            {
                List<DC.PaymentHistory> result = this.billingRepository.GetPaymentHistory(StudentId);
                List<DM.PaymentHistory> dbresult = mapper.Map<List<DM.PaymentHistory>>(result);

                return Task.FromResult(dbresult);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public Task<DM.PaymentHistory> AddPayment(DM.PaymentHistory payment)
        {
            ArgumentNullException.ThrowIfNull(payment);
            DC.PaymentHistory dbpaymenthistory = new()
            {
                BillId = payment.BillId,
                AmountPaid = payment.AmountPaid,
                PaymentDate = payment.PaymentDate                
            };
            DC.PaymentHistory result = this.billingRepository.AddPayment(dbpaymenthistory);          
            return Task.FromResult(payment);
        } 
        
        public Task<DM.PaymentHistory> UpdatePayment(DM.PaymentHistory payment)
        {
            ArgumentNullException.ThrowIfNull(payment);
            DC.PaymentHistory dbidtlitigation = this.billingRepository.GetpaymentbyId(payment.Id);




            dbidtlitigation.Id = payment.Id;
            dbidtlitigation.BillId = payment.BillId;
            dbidtlitigation.AmountPaid = payment.AmountPaid;
            dbidtlitigation.PaymentDate = payment.PaymentDate;             
           
            DC.PaymentHistory result = this.billingRepository.UpdatePayment(dbidtlitigation);          
            return Task.FromResult(payment);
        }

        

             public Task<bool> paymentexist(int id)
        {
            bool result = this.billingRepository.paymentexist(id);
            return Task.FromResult(result);
        } 
        
        public Task<bool> DeletePayment(int id)
        {
            ArgumentNullException.ThrowIfNull(id);
            DC.PaymentHistory dbidtlitigation = this.billingRepository.GetpaymentbyId(id);




            //dbidtlitigation.Id = payment.Id;
            //dbidtlitigation.BillId = payment.BillId;
            //dbidtlitigation.AmountPaid = payment.AmountPaid;
            //dbidtlitigation.PaymentDate = payment.PaymentDate;

            DC.PaymentHistory result = this.billingRepository.DeletePayment(dbidtlitigation);
            return Task.FromResult(true);
        }
        }
}
