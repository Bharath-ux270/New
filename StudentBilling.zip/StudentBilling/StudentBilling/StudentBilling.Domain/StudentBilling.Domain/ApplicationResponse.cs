﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Domain
{
    public class ApplicationResponse
    {
        public dynamic data { get; set; }

        public HttpStatusCode code { get; set; }

        public string? message { get; set; }
    }
}
