﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Domain
{
    public static class StatusMessages
    {
        public const string? InsertSuccess = " Submitted Successfully.";
        public const string? UpdateSuccess = "Updated Successfully";
        public const string? DeleteSuccess = "Deleted Successfully";
        public const string? DeleteFailed = "Deleted failed, Please Provide Required Information";
        public const string? UpdateFailed = "Update failed, Please Provide Required Information";
        public const string? InsertFailed = "Insert failed, Please Provide Required Information";
        public const string? Success = "Success";
        public const string? NoDataFound = "No Data Found";
        public const string? LoginSuccess = "Login Success";

    }
}
