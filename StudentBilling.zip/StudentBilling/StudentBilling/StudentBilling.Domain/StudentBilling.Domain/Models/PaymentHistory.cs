﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Domain.Models
{
    public partial class PaymentHistory
    {
        public int Id { get; set; }
        public int BillId { get; set; }
        public decimal AmountPaid { get; set; }
        public DateTime PaymentDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifyBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual BillingInfo Bill { get; set; }
    }
}
