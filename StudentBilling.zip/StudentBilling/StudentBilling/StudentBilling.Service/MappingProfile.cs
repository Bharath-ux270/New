﻿using AutoMapper;
using DC = StudentBilling.Data.Models;
using DM = StudentBilling.Domain.Models;

namespace StudentBilling.Service
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<DM.Student, DC.Student>().ReverseMap();
            CreateMap<DM.PaymentHistory, DC.PaymentHistory>().ReverseMap();

        }
    }
}