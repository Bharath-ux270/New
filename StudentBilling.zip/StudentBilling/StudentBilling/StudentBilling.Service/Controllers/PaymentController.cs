﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentBilling.Business.Contract;
using StudentBilling.Domain;
using StudentBilling.Domain.Models;
using System.Data;
using System.Net;

namespace StudentBilling.Service.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class PaymentController : ControllerBase
    {
        private IBillingBusiness billingBusiness;
        private readonly ILogger<PaymentController> _logger;
        public PaymentController(IBillingBusiness billingBusiness, ILogger<PaymentController> logger)
        {
            this.billingBusiness = billingBusiness;
            _logger = logger;   
        }

        [HttpGet]
        public async Task<ActionResult> GetPayments()

        {
            ApplicationResponse applicationResponse = new();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                List<PaymentHistory> result = await this.billingBusiness.GetPayments();
                if (result.Count > 0)
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.Success;
                    return Ok(applicationResponse);
                }
                else
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.NoDataFound;
                    return Ok(applicationResponse);
                }
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        [HttpGet]
        public async Task<ActionResult> GetPaymentByStudentId(int StudentId)

        {
            ApplicationResponse applicationResponse = new();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                List<PaymentHistory> result = await this.billingBusiness.GetPaymentHistory(StudentId);
                if (result.Count > 0)
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.Success;

                    return Ok(applicationResponse);
                }
                else
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.NoDataFound;
                    return Ok(applicationResponse);
                }
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        [HttpPost]
        public async Task<ActionResult> AddPayment(PaymentHistory payment)
        {
            ApplicationResponse applicationResponse = new ApplicationResponse();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                var result = await this.billingBusiness.AddPayment(payment);
                applicationResponse.code = HttpStatusCode.OK;
                applicationResponse.data = result;
                applicationResponse.message = StatusMessages.InsertSuccess;

                return Ok(applicationResponse);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        [HttpPost]
        public async Task<ActionResult> UpdatePayment(PaymentHistory payment)
        {
            ApplicationResponse applicationResponse = new ApplicationResponse();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                bool paymentexist = await this.billingBusiness.paymentexist(payment.Id);
                if(paymentexist)
                { 
                var result = await this.billingBusiness.UpdatePayment(payment);
                applicationResponse.code = HttpStatusCode.OK;
                applicationResponse.data = result;
                applicationResponse.message = StatusMessages.InsertSuccess;
                return Ok(applicationResponse);
                }
                else
                {
                    applicationResponse.code = HttpStatusCode.NoContent;
                    applicationResponse.data = null;
                    applicationResponse.message = StatusMessages.UpdateFailed;
                    return Ok(applicationResponse);
                }
                
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        [HttpPost]
        public async Task<ActionResult> DeletePayment(int id)
        {
            ApplicationResponse applicationResponse = new ApplicationResponse();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                bool paymentexist = await this.billingBusiness.paymentexist(id);
                if (paymentexist)
                {
                    var result = await this.billingBusiness.DeletePayment(id);
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.data = result;
                    applicationResponse.message = StatusMessages.InsertSuccess;
                    return Ok(applicationResponse);
                }
                else
                {
                    applicationResponse.code = HttpStatusCode.NoContent;
                    applicationResponse.data = null;
                    applicationResponse.message = StatusMessages.DeleteFailed;
                    return Ok(applicationResponse);
                }

            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        }
}
