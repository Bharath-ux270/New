﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StudentBilling.Data.BillingContext;
using StudentBilling.Domain;
using StudentBilling.Domain.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace StudentBilling.Service.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly StudentBillingContext dataContext;

        IConfiguration _configuration;

        public LoginController(IConfiguration configuration, StudentBillingContext context)
        {
            _configuration = configuration;
            this.dataContext = context;
        }

        [HttpPost]
       
        public async Task<IActionResult> PostLoginDetails(User _userData)
        {
            ApplicationResponse applicationResponse = new();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            if (_userData != null)
            {
                var resultLoginCheck = dataContext.Users
                    .Where(e => e.EmailId == _userData.EmailId && e.Password == _userData.Password)
                    .FirstOrDefault();
                if (resultLoginCheck == null)
                {
                    return BadRequest("Invalid Credentials");
                }
                else
                {
                    applicationResponse.message = StatusMessages.LoginSuccess;

                    var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("UserId", _userData.Id.ToString()),
                        new Claim("DisplayName", _userData.FullName),
                        new Claim("UserName", _userData.FullName),
                        new Claim("Email", _userData.EmailId),
                        new Claim("Role", _userData.Role)
                    };


                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        _configuration["Jwt:Issuer"],
                        _configuration["Jwt:Audience"],
                        claims,
                        expires: DateTime.UtcNow.AddMinutes(10),
                        signingCredentials: signIn);


                    _userData.AccessToken = new JwtSecurityTokenHandler().WriteToken(token);

                    return Ok(_userData);
                }
            }
            else
            {
                return BadRequest("No Data Posted");
            }
        }


    }
}
