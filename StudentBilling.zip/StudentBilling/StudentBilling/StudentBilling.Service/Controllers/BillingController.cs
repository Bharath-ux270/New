﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StudentBilling.Business.Contract;
using StudentBilling.Domain;
using StudentBilling.Domain.Models;
using System.Net;

namespace StudentBilling.Service.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class BillingController : ControllerBase
    {
        private IBillingBusiness billingBusiness;
        private readonly ILogger<PaymentController> _logger;
        public BillingController(IBillingBusiness billingBusiness, ILogger<PaymentController> logger)
        {
            this.billingBusiness = billingBusiness;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult> GetStudentBillById(int StudentId)

        {
            ApplicationResponse applicationResponse = new();
            string controllerName = ControllerContext.ActionDescriptor.ControllerTypeInfo.Name;
            string actionName = ControllerContext.ActionDescriptor.ActionName;
            try
            {
                List<BillingInfo> result = await this.billingBusiness.GetStudentBillById(StudentId);
                if (result.Count > 0)
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.Success;                  
                    return Ok(applicationResponse);
                }
                else
                {
                    applicationResponse.data = result;
                    applicationResponse.code = HttpStatusCode.OK;
                    applicationResponse.message = StatusMessages.NoDataFound;
                    return Ok(applicationResponse);
                }
            }
            catch (Exception ex)
            {
               
                throw(ex);
            }
        }


       

        

    }
}
