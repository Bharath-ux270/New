﻿using Microsoft.EntityFrameworkCore;
using StudentBilling.Data.BillingContext;
using StudentBilling.Data.Models;
using StudentBilling.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Repository.Implementation
{
    public class BillingRepository : IBillingRepository
    {
        private readonly StudentBillingContext dataContext;
        public BillingRepository(StudentBillingContext context)
        {
            this.dataContext = context;

        }

        public List<BillingInfo> GetStudentBillById(int StudentId)
        {
            var resultSet = dataContext.BillingInfos.Where(x=>x.StudentId == StudentId).ToList();
            return resultSet;
        } 
        
        public List<PaymentHistory> GetPayments()
        {
            var resultSet = dataContext.PaymentHistories.ToList();
            return resultSet;
        }
        public bool paymentexist(int id)
        {
            var resultSet = dataContext.PaymentHistories.Where(x => x.Id == id).Any();
            return resultSet;
        }
        
        public PaymentHistory DeletePayment(PaymentHistory payment)
        {
            dataContext.PaymentHistories.Remove(payment);
            return payment;
        }

           public List<PaymentHistory> GetPaymentHistory(int StudentId)
        {
            var resultSet = (from b in dataContext.PaymentHistories
                             join c in dataContext.BillingInfos on b.BillId equals c.Id
                             where c.StudentId == StudentId select b).ToList();
            return resultSet;
        }  
        
        public PaymentHistory GetpaymentbyId(int id)
        {
            var resultSet = (from b in dataContext.PaymentHistories
                             where b.Id == id select b).FirstOrDefault();
            return resultSet;
        }

        public PaymentHistory UpdatePayment(PaymentHistory payment)
        {
            dataContext.PaymentHistories.Update(payment);
            return payment;
        }
        public PaymentHistory AddPayment(PaymentHistory payment)
        {
            dataContext.PaymentHistories.Add(payment);
            return payment;
        }

        //public decimal GetByBillId(int billId)
        //{
        //    return dataContext.BillingInfos.FindAsync(billId);
            
        //}

    }
}
