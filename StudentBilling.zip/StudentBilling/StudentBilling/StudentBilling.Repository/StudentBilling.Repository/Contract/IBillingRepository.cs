﻿using StudentBilling.Data.BillingContext;
using StudentBilling.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentBilling.Repository.Contract
{
    public interface IBillingRepository
    {
        List<BillingInfo> GetStudentBillById(int StudentId);
        List<PaymentHistory> GetPayments();
        bool paymentexist(int id);
        List<PaymentHistory> GetPaymentHistory(int StudentId);
     //   BillingInfo GetByBillId(int billId);
        
        PaymentHistory AddPayment(PaymentHistory payment);
      PaymentHistory GetpaymentbyId(int id);
        PaymentHistory UpdatePayment(PaymentHistory payment);
        PaymentHistory DeletePayment(PaymentHistory payment);
    }
}
